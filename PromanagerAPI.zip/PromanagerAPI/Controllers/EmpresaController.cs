﻿using PromanagerAPI.Entities;
using PromanagerAPI.Models;
using PromanagerAPI.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;

namespace PromanagerAPI.Controllers
{
    public class EmpresaController : ApiController
    {
        static Dictionary<int, EmpresaVO> empresas = new Dictionary<int, EmpresaVO>();
        EmpresaService empresaService = new EmpresaService();

        //GET
       // public IEnumerable<EmpresaVO> Get() { 
        //    return new List<EmpresaVO>(empresas.Values); 
      //  }

        //GET
        public IEnumerable<Empresa> Get()
        {
            return empresaService.GetEmpresas();
        }

        public EmpresaVO Get(int id) {
            EmpresaVO encontrado;
            empresas.TryGetValue(id, out encontrado);
            return encontrado;
        }

        // POST api/Producto
        public bool Post([FromBody] EmpresaVO empresa)
        {
            EmpresaVO encontrado;
            empresas.TryGetValue(empresa.Id, out encontrado);

            if (encontrado == null) { 
                empresas.Add(empresa.Id, empresa);
                return true;
            }
            else
            {
                return false;
            }

        }

        //DELETE
        public bool Delete(int id)
        {
           return empresas.Remove(id);
        }

    }
}
