﻿using PromanagerAPI.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PromanagerAPI.Services
{


    public class EmpresaService
    {
        DBContextProManager dbContext = new DBContextProManager();
        public List<Empresa> GetEmpresas()
        {
            return dbContext.Empresa.ToList();
        }



    }
}