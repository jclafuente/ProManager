﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PromanagerAPI.Models
{
    public class EmpresaVO
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Ruc { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }

        // ....
        public string create_user { get; set; }
        public string create_time { get; set; }
        public string update_user { get; set; }
        public string update_time { get; set; }

    }
}