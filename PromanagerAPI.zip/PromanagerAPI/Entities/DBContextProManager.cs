using PromanagerAPI.Entities;
using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace PromanagerAPI.Entities
{
    public partial class DBContextProManager : DbContext
    {
        public DBContextProManager()
            : base("name=DBContextProManager")
        {
            this.Configuration.LazyLoadingEnabled = false;
            //this.Configuration.ProxyCreationEnabled = false;
        }

        public virtual DbSet<Contacto> Contacto { get; set; }
        public virtual DbSet<Empresa> Empresa { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Empresa>()
                .HasMany(e => e.contacto)
                .WithOptional(e => e.empresa)
                .HasForeignKey(e => e.empresa_id);
        }
    }
}
