﻿using ProManagerDAO;
using ProManagerDAO.Entities;
using ProManagerLN.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace ProManagerLN.Services
{
    public class EmpresaServiceLN
    {
        private ProManagerContext  dbContext = new ProManagerContext();

        public async Task<EmpresaModel> GetEmpresaById(int id) {
            return await dbContext.Empresa.Select(s => new EmpresaModel
            {
                id = s.id
            }).FirstOrDefaultAsync(s=> s.id == id);
        }

        public List<Empresa> GetEmpresas()
        {
            return dbContext.Empresa.ToList();
        }


    }
}