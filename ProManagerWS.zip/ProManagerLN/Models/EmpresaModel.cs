﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProManagerLN.Models
{
    public class EmpresaModel
    {

        public long id { get; set; }

        public string ruc { get; set; }


        public string nombre { get; set; }


        public string direccion { get; set; }


        public string telefono { get; set; }


        public string web { get; set; }


        public string logo { get; set; }
    }
}