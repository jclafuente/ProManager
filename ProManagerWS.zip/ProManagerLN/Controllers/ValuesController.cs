﻿using ProManagerDAO.Entities;
using ProManagerLN.Models;
using ProManagerLN.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace ProManagerLN.Controllers
{
    public class ValuesController : ApiController
    {

        private EmpresaServiceLN service = new EmpresaServiceLN();

        // GET api/values
        public IEnumerable<Empresa> Get()
        {
            return service.GetEmpresas();
        }


       

       
    }
}
